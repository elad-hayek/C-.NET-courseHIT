﻿namespace Ex02_1
{
    public enum eGameMode
    {
        PlayerVsPlayer = 1,
        PlayerVsComputer = 2
    }
}