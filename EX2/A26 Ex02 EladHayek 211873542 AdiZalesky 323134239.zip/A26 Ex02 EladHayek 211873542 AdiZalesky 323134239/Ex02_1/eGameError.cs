﻿namespace Ex02_1
{
    public enum eGameError
    {
        NoError,
        InvalidBoardDimensions,
        InvalidColumn,
        ColumnIsFull
    }
}