﻿namespace Ex02_1
{
    public class Program
    {
        public static void Main()
        {
            GameManager gameManager = GameManager.CreateGameManager();
            gameManager.StartGame();
        }
    }
}