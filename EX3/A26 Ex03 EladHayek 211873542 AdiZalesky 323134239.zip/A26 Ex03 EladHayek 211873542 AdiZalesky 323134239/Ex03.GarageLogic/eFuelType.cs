﻿namespace Ex03.GarageLogic
{
    public enum eFuelType
    {
        Soler = 1,
        Octan95,
        Octan96,
        Octan98,
        None
    }
}
