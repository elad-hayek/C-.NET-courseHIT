﻿namespace Ex03.GarageLogic
{
    public enum eCarColor
    {
        Blue,
        Green,
        White,
        Black
    }
}
