﻿namespace Ex03.GarageLogic
{
    public enum eVehicleQuestion
    {
        WheelManufacturer = 1,
        CurrentWheelAirPressure,
        EnergySourcePercentage,
        CarColor,
        NumberOfDoors,
        LicenseType,
        EngineCapacity,
        IsCarryingHazardousMaterials,
        CargoVolume
    }
}
