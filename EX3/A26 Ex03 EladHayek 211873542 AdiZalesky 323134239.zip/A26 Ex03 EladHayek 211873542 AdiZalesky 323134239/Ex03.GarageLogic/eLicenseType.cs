﻿namespace Ex03.GarageLogic
{
    public enum eLicenseType
    {
        A1,
        A2,
        AA,
        B
    }
}
