﻿
namespace Ex03.GarageLogic
{
    public enum eVehicleStatus
    {
        InRepair = 1,
        Repaired,
        Paid
    }
}
