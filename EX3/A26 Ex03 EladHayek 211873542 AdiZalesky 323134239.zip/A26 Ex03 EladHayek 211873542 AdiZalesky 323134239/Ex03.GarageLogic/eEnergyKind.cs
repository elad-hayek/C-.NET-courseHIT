﻿namespace Ex03.GarageLogic
{
    public enum eEnergyKind
    {
        Fuel,
        Electric
    }
}
