﻿namespace Ex03.ConsoleUI
{
    public class Program
    {
        public static void Main()
        {
            UIManager uiManager = new UIManager();
            uiManager.ShowMenu();
        }
    }
}
