﻿namespace Ex03.ConsoleUI
{
    public enum eMenuOption
    {
        LoadSystemFromFile = 1,
        EnterNewVehicle,
        DisplayLicenseNumbers,
        ChangeVehicleStatus,
        InflateTiresToMax,
        RefuelVehicle,
        RechargeElectricVehicle,
        DisplayVehicleDetails,
        Exit,
    }
}
