﻿namespace Ex04.Menus.Interfaces
{
    public interface IProgramExitable
    {
        void Exit();
    }
}
